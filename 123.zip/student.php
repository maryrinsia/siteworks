<html>
    <head>
        <title>Student Dashboard</title>
    </head>
    <body>
        <div><h1>Student Dashboard</h1></div>
    </body>
</html>